import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class main {
    public static void main(String[] arg3) {
        //reading from console
        lexecarAnalyzing lexObject = new lexecarAnalyzing();
        
        String lexeme;
        Scanner sc = new Scanner(System.in);
        System.out.println("enter your code : ");
        lexeme = sc.nextLine();
        lexObject.generateTokens(lexeme);
      // reading from file 
      try {
      File myObj = new File("C:\\Users\\maime\\Desktop\\scanner\\src\\input.txt");
      Scanner myReader = new Scanner(myObj);
      while (myReader.hasNextLine()) {
        String data = myReader.nextLine();
         lexObject.generateTokens(data);
      }
      myReader.close();
    } catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    }

}