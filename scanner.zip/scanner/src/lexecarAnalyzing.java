import java.util.*;
//import javafx.application.Application;

public class lexecarAnalyzing  {

    public void generateTokens(String lexeme){

        final String[][] specialWords ={
                                                {"Yesif-Otherwise","Condition"},
                                                {"Omw","Integer"},
                                                {"SIMww","SInteger"},
                                                {"Chji","Character"},
                                                {"Seriestl","String"},
                                                {"IMwf","Float"},
                                                {"SIMwf","SFloat"},
                                                {"NOReturn","Void"},
                                                {"RepeatWhen","Loop"},
                                                {"Reiterate","Loop"},
                                                {"GetBack","Return"},
                                                {"OutLoop","Break"},
                                                {"Loli","Struct"},
                                                {"+","Arithmetic Operation"},
                                                {"-","Arithmetic Operation"},
                                                {"*","Arithmetic Operation"},
                                                {"/","Arithmetic Operation"},
                                                {"&&","Logic operators"},
                                                {"||","Logic operators"},
                                                {"~","Logic operators"},
                                                {"==","relational operator"},
                                                {"<","relational operator"},
                                                {">","relational operator"},
                                                {"!=","relational operator"},
                                                {"<=","relational operator"},
                                                {">=","relational operator"},
                                                {"=","Assignment operator"},
                                                {"->","Access Operator"},
                                                {"{","Braces"},
                                                {"}","Braces"},
                                                {"[","Braces"},
                                                {"]","Braces"},
                                                {"(","Braces"},
                                                {")","Braces"},
                                                {"\'","Quotation Mark"},
                                                {"\"","Quotation Mark"},
                                                {"/@","Comment"},
                                                {"@/","Comment"},
                                                {"/^","Comment"},
                                                {"$","Token Delimiter"},
                                                {".","Line Delimiter"},
                                                {"Include","Inclusion"},
                                                {"Start","start"},
                                                {"Last","End"}
        };

        String tokenList="";
        int state = 1, pl = 0;
        int lLength = (lexeme.length());
        char c;

        while (pl < (lLength)) {
            c = lexeme.charAt(pl);
            switch (state) {
                case 1:
                    tokenList = tokenList + c;
                    if (isLetter(c)) {
                        state = 2;
                    } else if (c == '$' || c == '(' || c == ')' || c == '.' || c == '+' || c == '*' || c == '[' || c == ']' || c == '{' || c == '}') {
                        state = 4;
                    } else if (isNumber(c)) {
                        state = 7;
                    } else if (c == '~') {
                        state = 6;
                    } else if (c == '/') {
                        state = 3;
                    } else if (c == '!') {
                        state = 11;
                    } else if (c == '&') {
                        state = 12;
                    } else if (c == '|') {
                        state = 13;
                    } else if (c == '<' || c == '=' || c == '>') {
                        state = 14;
                    } else if (c == '-') {
                        state = 15;
                    } else {
                        System.out.println(c + "is invalid    not matched");
                        tokenList = "";
                    }
                    break;

                case 2:
                    if (isLetter(c) || isNumber(c) || c == '_') {
                        tokenList = tokenList + c;
                    } else {
                        checker(tokenList, specialWords);
                        pl--;
                        state = 1;
                        tokenList = "";
                    }
                    break;

                case 4:
                    checker(tokenList, specialWords);
                    pl--;
                    state = 1;
                    tokenList = "";
                    break;

                case 7:
                    if (isNumber(c)) {
                        tokenList = tokenList + c;
                    } else {
                        System.out.println(tokenList +" : is constant  matched");
                        pl--;
                        state = 1;
                        tokenList = "";
                    }
                    break;

                case 6:
                    checker(tokenList, specialWords);
                    pl--;
                    state = 1;
                    tokenList = "";
                    break;

                case 3:
                    if (c == '^' || c == '@') {
                        tokenList = tokenList + c;
                        c=lexeme.charAt(pl);
                        checker(tokenList, specialWords);
                        tokenList="";
                        while(c!='\n'){
                            pl++;
                            c=lexeme.charAt(pl);
                            if(c=='@'){
                                pl++;
                                tokenList = tokenList+c;
                                c=lexeme.charAt(pl);
                                if(c=='/'){
                                    tokenList = tokenList+c;
                                    pl++;
                                    break;
                                }
                            }
                        }

                    }
                    checker(tokenList, specialWords);
                    pl--;
                    state = 1;
                    tokenList = "";
                    break;

                case 11:
                    if (c == '=') {
                        tokenList = tokenList+c;
                        pl++;
                    }
                    checker(tokenList, specialWords);
                    pl--;
                    state = 1;
                    tokenList = "";
                    break;

                case 12:
                    if (c == '&') {
                        tokenList = tokenList+c;
                        pl++;
                    }
                    checker(tokenList, specialWords);
                    pl--;
                    state = 1;
                    tokenList = "";

                    break;

                case 13:
                    if (c == '|') {
                        tokenList = tokenList+c;
                        pl++;
                    }
                    checker(tokenList, specialWords);
                    pl--;
                    state = 1;
                    tokenList = "";

                    break;

                case 14:
                    if (c == '=') {
                        tokenList = tokenList+c;
                        pl++;
                    }
                    checker(tokenList, specialWords);
                    pl--;
                    state = 1;
                    tokenList = "";
                    break;

                case 15:
                    if (c == '>') {
                        tokenList = tokenList+c;
                        pl++;
                    }
                    checker(tokenList, specialWords);
                    pl--;
                    state = 1;
                    tokenList = "";
                    break;

                default:

            }
            pl++;
        }
    }

    static boolean isLetter ( char c){
        if (c >= 'a' && c <= 'z')
            return true;
        if (c >= 'A' && c <= 'Z')
            return true;

        return false;

    }

    static boolean isNumber ( char c){
        if (c >= '0' && c <= '9')
            return true;

        return false;
    }

    static void checker (String tokenList, String [][]specialWords){
        for (int i = 0; i < specialWords.length; i++) {
            if (tokenList.equals(specialWords[i][0])) {
                System.out.println(tokenList + ": " + specialWords[i][1] + " matches");
                return;
            }
        }
        if (isLetter(tokenList.charAt(0)) || tokenList.charAt(0)=='_') {
            System.out.println(tokenList + ": is identifier  not matched");
        } else {
            System.out.println(tokenList + ": is invalid  not matched");
        }

    }
}